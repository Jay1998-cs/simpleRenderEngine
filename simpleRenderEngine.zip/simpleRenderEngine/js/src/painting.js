"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const canvas_1 = require("canvas");
const utils_1 = require("../utils/utils");
const HTMLParser_1 = require("./HTMLParser");
const fs_1 = require("fs");
//////////////
// 程序入口
function painting(layoutBox, outputPath = "") {
    const { x, y, width, height } = layoutBox.boxDimensions.content;
    // 创建二维画布
    const canvas = (0, canvas_1.createCanvas)(width, height);
    const ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff";
    ctx.fillRect(x, y, width, height);
    // 绘制布局元素
    renderlayoutElem(layoutBox, ctx);
    // 输出绘制结果PNG图片
    createPNG(canvas, outputPath);
}
exports.default = painting;
// * 遍历布局树，迭代绘制每一个布局元素
function renderlayoutElem(layoutBox, ctx, parent) {
    // 绘制当前元素
    renderBackground(layoutBox, ctx);
    renderBorder(layoutBox, ctx);
    renderText(layoutBox, ctx, parent);
    // 绘制后代
    if (!layoutBox.children || layoutBox.children.length === 0) {
        return;
    }
    for (const child of layoutBox.children) {
        renderlayoutElem(child, ctx, layoutBox);
    }
}
// 绘制背景颜色
function renderBackground(layoutBox, ctx) {
    const { x, y, width, height } = layoutBox.boxDimensions.borderBox();
    const bgColor1 = (0, utils_1.getStyleValueByLayoutNode)(layoutBox, "background-color");
    const bgColor2 = (0, utils_1.getStyleValueByLayoutNode)(layoutBox, "background").split(" ")[0];
    ctx.fillStyle = bgColor1 || bgColor2 || "#fff"; // 默认背景色白色
    ctx.fillRect(x, y, width, height);
}
// 绘制边框
function renderBorder(layoutBox, ctx) {
    const { x, y, width, height } = layoutBox.boxDimensions.borderBox();
    const { top, right, bottom, left } = layoutBox.boxDimensions.border;
    const borderColor1 = (0, utils_1.getStyleValueByLayoutNode)(layoutBox, "border-color");
    const borderColor2 = (0, utils_1.getStyleValueByLayoutNode)(layoutBox, "border").split(" ")[0];
    if (!borderColor1 || !borderColor2) {
        return;
    }
    ctx.fillStyle = borderColor1 || borderColor2;
    // left
    ctx.fillRect(x, y, left, height);
    // top
    ctx.fillRect(x, y, width, top);
    // right
    ctx.fillRect(x + width - right, y, right, height);
    // bottom
    ctx.fillRect(x, y + height - bottom, width, bottom);
}
// 绘制文本
function renderText(layoutBox, ctx, parent) {
    var _a, _b, _c, _d, _e;
    if (((_b = (_a = layoutBox.styleNode) === null || _a === void 0 ? void 0 : _a.node) === null || _b === void 0 ? void 0 : _b.nodeType) === HTMLParser_1.NodeType.Text) {
        const { x = 0, y = 0, width } = (parent === null || parent === void 0 ? void 0 : parent.boxDimensions.content) || {};
        const styles = ((_c = layoutBox.styleNode) === null || _c === void 0 ? void 0 : _c.values) || {};
        const fontSize = styles["font-size"] || "14px";
        const fontFamily = styles["font-family"] || "serif";
        const fontWeight = styles["font-weight"] || "normal";
        const fontStyle = styles["font-style"] || "normal";
        ctx.fillStyle = styles.color || "#000"; // 默认黑色字体
        ctx.font = `${fontStyle} ${fontWeight} ${fontSize} ${fontFamily}`;
        ctx.fillText((_e = (_d = layoutBox.styleNode) === null || _d === void 0 ? void 0 : _d.node) === null || _e === void 0 ? void 0 : _e.nodeValue, x, y + parseInt(fontSize), width);
    }
}
// 输出渲染结果图
function createPNG(canvas, outputPath) {
    canvas.createPNGStream().pipe((0, fs_1.createWriteStream)(outputPath));
}
