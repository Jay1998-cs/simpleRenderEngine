"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.KEYS = exports.Display = exports.BoxType = void 0;
// CSS盒子类型
var BoxType;
(function (BoxType) {
    BoxType["BlockBox"] = "BlockBox";
    BoxType["InlineBox"] = "InlineBox";
    BoxType["AnonymousBox"] = "AnonymousBox";
})(BoxType || (exports.BoxType = BoxType = {}));
// 定义display属性值(不支持flex等其他属性)
var Display;
(function (Display) {
    Display["Inline"] = "inline";
    Display["Block"] = "block";
    Display["None"] = "none";
})(Display || (exports.Display = Display = {}));
// 布局关键词
exports.KEYS = {
    auto: "auto",
    ml: "margin-left",
    mr: "margin-right",
    mt: "margin-top",
    mb: "margin-bottom",
    pl: "padding-left",
    pr: "padding-right",
    pt: "padding-top",
    pb: "padding-bottom",
    bl: "border-left",
    br: "border-right",
    bt: "border-top",
    bb: "border-bottom",
};
