"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const Rect_1 = __importDefault(require("./Rect"));
// CSS盒子
class BoxDimensions {
    // 初始化盒子内容、内边距、边框、外边距
    constructor() {
        const initValue = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
        };
        this.content = new Rect_1.default();
        this.padding = Object.assign({}, initValue);
        this.border = Object.assign({}, initValue);
        this.margin = Object.assign({}, initValue);
    }
    paddingBox() {
        return this.content.expandedBy(this.padding);
    }
    borderBox() {
        return this.paddingBox().expandedBy(this.border);
    }
    marginBox() {
        return this.borderBox().expandedBy(this.margin);
    }
}
exports.default = BoxDimensions;
