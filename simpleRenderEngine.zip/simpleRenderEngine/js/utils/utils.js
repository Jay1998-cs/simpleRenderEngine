"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStyleValueByLayoutNode = exports.getBoxType = exports.getDisplayValue = exports.transformValueSafe = exports.sum = exports.removeBetweenSpaces = void 0;
const type_1 = require("../src/layout/type");
// 删除字符之间多余的空格或换行符，只保留一个，例如removeBetweenSpaces("1  2  3 \n  4 5") 结果得"1 2 3 4 5"
function removeBetweenSpaces(str) {
    let index = 0;
    const len = str.length;
    let hasSpace = false;
    const symbols = [" ", "\n"];
    let res = "";
    while (index < len) {
        let s = str[index];
        if (symbols.includes(s)) {
            // 只要遇到空格或换行符，hasSpace就设为true，并且只添加一个空格
            // （例如，当遇到连续空格或换行符时，hasSpace为true，就不会增加空格）
            if (!hasSpace) {
                hasSpace = true;
                res += " ";
            }
        }
        else {
            // 只有遇到非空格和换行符时，才修改hasSpace标志
            res += s;
            hasSpace = false;
        }
        ++index;
    }
    return res;
}
exports.removeBetweenSpaces = removeBetweenSpaces;
// 数组求和
function sum(...args) {
    return args.reduce((prev, cur) => {
        if (cur === "auto") {
            return prev;
        }
        return prev + parseInt(String(cur));
    }, 0);
}
exports.sum = sum;
// 将val取值转换为number类型
function transformValueSafe(val) {
    if (val === "auto")
        return 0;
    return parseInt(String(val));
}
exports.transformValueSafe = transformValueSafe;
// 获取样式节点的display属性值，如果没有则默认设为 Inline Box
function getDisplayValue(styleNode) {
    var _a, _b;
    return (_b = (_a = styleNode.values) === null || _a === void 0 ? void 0 : _a.display) !== null && _b !== void 0 ? _b : type_1.Display.Inline;
}
exports.getDisplayValue = getDisplayValue;
// 获取盒子的类型：匿名、内联、块
function getBoxType(styleNode) {
    if (!styleNode)
        return type_1.BoxType.AnonymousBox;
    const display = getDisplayValue(styleNode);
    if (display === type_1.Display.Block)
        return type_1.BoxType.BlockBox;
    return type_1.BoxType.InlineBox;
}
exports.getBoxType = getBoxType;
// 输入布局节点，获取某个css属性值
function getStyleValueByLayoutNode(layoutNode, key) {
    var _a, _b;
    return (_b = (_a = layoutNode.styleNode) === null || _a === void 0 ? void 0 : _a.values[key]) !== null && _b !== void 0 ? _b : "";
}
exports.getStyleValueByLayoutNode = getStyleValueByLayoutNode;
