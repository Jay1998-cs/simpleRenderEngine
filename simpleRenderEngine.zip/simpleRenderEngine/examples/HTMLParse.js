const { HTMLParser } = require("../js/index");

function parse(html) {
  const parser = new HTMLParser();
  return JSON.stringify(parser.parse(html), null, 4);
}

// console.log(parse("<html><body><div>test!</div></body></html>"));
// console.log(
//   parse(`
//     <html>
//         <body id=" body " data-index="1" style="color: red; background: yellow;">
//             <div class="lightblue test">test!</div>
//         </body>
//     </html>
// `)
// );
// console.log(
//   parse(`
//     <div class="lightblue test" id=" div " data-index="1">test!</div>
// `)
// );

console.log(
  parse(`
<html>
  <body id=" body " data-index="1" style="color: red; background: yellow;">
      <div>
          <div class="lightblue test">test1!</div>
          <div class="lightblue test">
              <div class="foo">foo</div>
          </div>
      </div>
  </body>
</html>
`)
);
