const {
  HTMLParser,
  CSSParser,
  getLayoutTree,
  getStyleTree,
  BoxDimensions,
  painting,
} = require("../js/index");
const { join } = require("path");

function parseHTML(html) {
  const parser = new HTMLParser();
  return parser.parse(html);
}

function parseCSS(css) {
  const parser = new CSSParser();
  return parser.parse(css);
}

// DOM树
const domTree = parseHTML(`
            <html>
                <body id=" body " data-index="1" style="color: blue; background: gray;">
                    <div>
                        <div class="title">你好,hello world!</div>
                        <div class="box">
                            <div class="text">Hello@HLJ</div>
                        </div>
                        <p>
                            <p>www</p>
                            <p>word wide web</p>
                        </p>
                    </div>
                </body>
            </html>
`);

// CSS规则
const cssRules = parseCSS(`
            * {
                display: block;
            }

            body {
                display: block;
                font-size: 88px;
                color: #000;
                padding-left: 50px;
                height: 600px;
            }

            .title {
                font-size: 20px;
                height: 50px;
                background: lightblue;
                margin-top: 20px;
            }

            .box {
                font-size: 16px;
                width: 200px;
                height: 200px;
                background: blue;
                border-color: green;
                border: 10px;
                margin: 10px;
            }

            .text {
                width: 100px;
                height: 100px;
                background: pink;
                color: #000;
                margin: 50px;
                font-size: 16px;
            }

            p {
                height: 24px;
                font-size: 24px;
            }
`);

// 样式树
const styleTree = getStyleTree(domTree, cssRules);

// 布局树
const dimensions = new BoxDimensions();
dimensions.content.width = 800;
dimensions.content.height = 800;
const layoutTree = getLayoutTree(styleTree, dimensions);

// 渲染
painting(layoutTree, join(__dirname, "./example.png"));

// 检查解析结果
// console.log("domTree: \n", JSON.stringify(domTree, null, 4), "\n"); // test ok
// console.log("cssRules:\n", JSON.stringify(cssRules, null, 4), "\n"); // test ok
// console.log(JSON.stringify(styleTree, null, 4), "\n"); // test ok
// console.log(JSON.stringify(layoutTree, null, 4), "\n"); // test ok
